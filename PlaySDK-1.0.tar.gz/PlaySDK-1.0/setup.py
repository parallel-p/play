from distutils.core import setup

files = ["*.py", "colorama/*.py", "development_tools/*.py",
        "lib/*.py", "pepelac/*.py", "tournament_stages/*.py", "pepelac/bots/*.*",
        ]

setup(name = "PlaySDK",
    version = "1.0",
    description = "Play SDK for Pepelac",
    author = "Parallel P",
    author_email = "lksh@lksh.ru",
    url = "http://ejudge.lksh.ru/P/play.html",
    packages = ['PlaySDK'],
    package_data = {'PlaySDK' : files},
    long_description = open('README').read(),
) 