class NoResultsException(Exception):
    pass
