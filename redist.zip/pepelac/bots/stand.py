import sys

while True:
    print('STAND')
    sys.stdout.flush()
